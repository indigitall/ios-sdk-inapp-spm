//
//  INRequestInAppTopicList.h
//  IndigitallSdk
//
//  Created by Carlos on 17/7/25.
//

#import "INBaseRequest.h"

NS_ASSUME_NONNULL_BEGIN

@interface INRequestInAppTopicList : INBaseRequest

@property int limit;
@property int page;

- (instancetype)initWithPage: (int) page;

@end

NS_ASSUME_NONNULL_END
