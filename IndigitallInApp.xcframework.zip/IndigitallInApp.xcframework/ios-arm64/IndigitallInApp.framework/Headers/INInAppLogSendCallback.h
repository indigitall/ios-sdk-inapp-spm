//
//  INInAppLogSendCallback.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 10/6/26.
//

#import <Foundation/Foundation.h>
#import "INBaseCallback.h"

NS_ASSUME_NONNULL_BEGIN

@interface INInAppLogSendCallback : INBaseCallback

@property (nonatomic, copy, nullable) void (^onFinish)(void);
- (instancetype)initWithOnFinish:(void (^ _Nullable)(void))onFinish;

@end

NS_ASSUME_NONNULL_END
