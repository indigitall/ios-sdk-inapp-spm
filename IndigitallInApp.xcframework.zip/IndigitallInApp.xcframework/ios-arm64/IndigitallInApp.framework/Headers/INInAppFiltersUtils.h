//
//  INInAppFiltersUtils.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 20/5/25.
//

#import <Foundation/Foundation.h>
#import "INInApp.h"
NS_ASSUME_NONNULL_BEGIN

@interface INInAppFiltersUtils : NSObject

+ (NSArray<NSString *>*) getInAppIdFromArraylistOfInAppWithSchemaCode: (NSString *)schemaCode;
+ (NSArray<INInApp *> *)getAllInAppToIgnoreWithSchemaCode:(NSString *)schemaCode;
+ (NSArray<INInApp *> *)filterInAppToIgnoreWithInAppList:(NSArray<INInApp *> *)inAppList;

@end

NS_ASSUME_NONNULL_END
