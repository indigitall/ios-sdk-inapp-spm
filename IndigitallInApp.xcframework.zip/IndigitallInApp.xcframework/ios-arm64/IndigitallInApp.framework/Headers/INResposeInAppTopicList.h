//
//  INResposeInAppTopicList.h
//  IndigitallSdk
//
//  Created by Carlos on 18/7/25.
//

#import "INBaseResponse.h"
#import "INBaseCallback.h"
#import "INInApp.h"
#import "INInAppLog.h"

NS_ASSUME_NONNULL_BEGIN

@interface INResposeInAppTopicList : INBaseResponse

@property (nonatomic) NSArray<INInAppTopic*> *topics;

- (id)initWithCallback:(INBaseCallback *_Nullable)callback;
- (void) processWithData:(NSData *_Nullable)data urlResponse:(NSURL *)urlResponse error:(NSError *_Nullable)error;

@end

NS_ASSUME_NONNULL_END
