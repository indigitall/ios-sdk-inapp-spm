//
//  INInAppTopicListCallback.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 20/8/25.
//

#import <Foundation/Foundation.h>
#import "INInAppTopic.h"
#import "INBaseCallback.h"
#import "INInAppError.h"
#import "INRequestInAppTopicList.h"
#import "INInAppPageTopic.h"

NS_ASSUME_NONNULL_BEGIN

@interface INInAppTopicListCallback : INBaseCallback

@property (nonatomic) NSArray<INInAppTopic*> *topics;
@property (nonatomic) INRequestInAppTopicList *request;
@property (nonatomic) int currentPage;

@property (nonatomic, copy) void (^onError)(INInAppError * error);
@property (nonatomic, copy, nullable) void (^onSuccess)(INInAppPageTopic *inAppPageTopic);

- (instancetype) initWithCurrentPage:(int)currentPage
                           onSuccess: (nullable void(^)(INInAppPageTopic *inAppPageTopic)) onSuccess
                           onError: (nullable void(^)(INInAppError * error)) onError
                             request: (INRequestInAppTopicList*) request;
- (void) proccessDataWithStatusCode:(int)statusCode message:(NSString *)message data:(NSMutableDictionary *_Nullable)data;

@end

NS_ASSUME_NONNULL_END
