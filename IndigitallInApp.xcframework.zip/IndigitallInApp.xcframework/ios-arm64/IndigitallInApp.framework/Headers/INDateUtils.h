//
//  DateUtils.h
//  Indigitall
//
//  Created by indigitall on 12/3/21.
//  Copyright © 2021 Indigital. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface INDateUtils : NSObject

+ (NSDate *)getDateNow;
+ (NSDate *)getDate: (NSString *)dateString;
+ (NSDate *)getDateExpired: (NSDateComponents *)dateComponents;
+ (NSString *)getDateString: (NSDate *)date;
/// Normalizes a date string into the canonical UTC format: yyyy-MM-dd'T'HH:mm:ssZ
/// Returns nil if parsing fails.
+ (nullable NSString *)normalizeDateString:(NSString *)dateString;

@end

NS_ASSUME_NONNULL_END
