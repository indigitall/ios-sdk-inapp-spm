//
//  BaseResponse.h
//  indigitall-objc
//
//  Created by indigitall on 02/09/2019.
//  Copyright © 2019 indigitall. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "INBaseCallback.h"

#import "INLog.h"

NS_ASSUME_NONNULL_BEGIN

@interface INBaseResponse : NSObject


@property (nonatomic) INBaseCallback *callback;

@property (nonatomic) NSMutableDictionary *responseData;

@property (nonatomic) NSArray* responseArray;
@property (nonatomic) long statusCode;
@property (nonatomic) NSString* message;
@property (nonatomic) BOOL shouldLog;

// Request metadata for consolidated logging
@property (nonatomic, copy, nullable) NSString *requestMethod;
@property (nonatomic, copy, nullable) NSString *requestURL;
@property (nonatomic, strong, nullable) NSDictionary *requestBody;
@property (nonatomic) NSTimeInterval requestStartTime;

// Static log getters and setters
- (INLog *) getLog;
- (void) setLog:(INLog *)logger;

- (id) initWithCallback: (INBaseCallback *_Nullable) callback;

- (void) processWithData: (NSData*_Nullable)data urlResponse:(NSURL*)urlResponse error:(NSError*_Nullable)error /*handler: (void (^)(BaseHandler *handler)) completion*/;



@end

NS_ASSUME_NONNULL_END
