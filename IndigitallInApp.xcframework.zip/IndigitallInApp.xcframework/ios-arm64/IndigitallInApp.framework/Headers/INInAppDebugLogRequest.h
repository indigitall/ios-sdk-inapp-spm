//
//  INInAppDebugLogRequest.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 10/6/26.
//

#import <Foundation/Foundation.h>
#import "INBaseRequest.h"

NS_ASSUME_NONNULL_BEGIN

@interface INInAppDebugLogRequest : INBaseRequest
@property (nonatomic) NSString *level;
@property (nonatomic) NSString *message;
@property (nonatomic) NSDictionary *metadata;
-(id) initWithLevel: (NSString *)level message: (NSString * )message metadata: (NSDictionary * _Nullable)metadata;
- (id) sendDebugLog;
@end

NS_ASSUME_NONNULL_END
