//
//  INCustomerEventRequest.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 12/1/26.
//

#import <Foundation/Foundation.h>
#import "INBaseEventRequest.h"

NS_ASSUME_NONNULL_BEGIN

@interface INCustomerEventRequest : INBaseEventRequest

@property (nonatomic) NSString *customerId;
/// customer journey
@property (nonatomic) NSString *eventType;
@property (nonatomic) NSDictionary *customData;


- (id) postCustomEventRequest;
@end

NS_ASSUME_NONNULL_END
