//
//  INInAppDevice.h
//  Indigitall
//
//  Created by indigitall on 20/6/22.
//  Copyright © 2022 Indigital. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "INCoreDevice.h"

NS_ASSUME_NONNULL_BEGIN

@interface INInAppDevice : INCoreDevice

- (id)init;
- (id)initWithData:(NSMutableDictionary * _Nullable)data;

- (id)initWithNoData;

- (void)update:(NSDictionary *)json;

@end

NS_ASSUME_NONNULL_END
